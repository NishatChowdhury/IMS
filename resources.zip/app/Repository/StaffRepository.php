<?php
/**
 * Created by PhpStorm.
 * User: smartrahat
 * Date: 11/5/2019
 * Time: 5:11 PM
 */

namespace App\Repository;


class StaffRepository
{

}