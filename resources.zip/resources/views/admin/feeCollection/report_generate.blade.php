@extends('layouts.fixed')

@section('title', 'Fee Collection')

@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Fee Collection</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">{{ __('Fee Collection') }}</a></li>
                        <li class="breadcrumb-item active">{{ __('Collect Fees') }}</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- /.Search-panel -->
    <section class="content no-print">
        <div class="container-fluid">
            {{-- start --}}
            <div class="col-lg-12 col-sm-8 col-md-8 col-xs-12 ">
                <div class="card card-primary card-outline">
                    <div class="card-body " style="padding-bottom:0">
                        <form method="get" action="{{ route('report.generate') }}">
                            <div class="form-row">
                                <div class="form-group col-md-2">
                                    <label>From</label>
                                    <input type="date" name="from" class="form-control">
                                </div>
                                <div class="form-group col-md-2">
                                    <label>To</label>
                                    <input type="date" name="to" class="form-control">
                                </div>
                                <div class="form-group col-md-3">
                                    <label>Item</label>
                                    <select name="" id="" class="form-control">
                                        <option value="">class one</option>
                                        <option value="">class tow</option>
                                        <option value="">class three</option>
                                        <option value="">class four</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-1" style="margin-top: 30px">
                                    <button type="submit"
                                        class="btn btn-info btn-md btn-block">{{-- <i class="fa fa-search"></i>&nbsp; --}}Search</button>
                                </div>
                                <div class="form-group col-md-1" style="margin-top: 30px">
                                    <button class="btn btn-success btn-md btn-block"
                                        onclick="window.print(); return false;"><i
                                            class="fa fa-print"></i>&nbsp;Print</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.card -->
            </div>

        </div>{{-- end --}}
    </section>


    @if (isset($stupays))
         {{dump($stupays)}}
            
    @endif
    
       


        
@stop
