
@extends('layouts.fixed')

@section('title','Institution Mgnt | Journal')

@section('content')
    @livewire('list-journal');
@endsection