<div class="tab-pane fade" id="bank-slip" role="tabpanel">
    <div class="container">
        <div class="row">
            <div class="col-12 mx-auto">
                <div class="row form-group">
                    <label for="example-number-input" class="col-2 col-form-label text-right">Upload Bank Slip</label>
                    <div class="col-10">
                        <input name="slip" type="file">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
