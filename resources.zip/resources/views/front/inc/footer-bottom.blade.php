<div class="footer-bottom bg-dark py-5 text-center">
    <div class="container">
        <p class="text-white-0_5 mb-0">&copy; 2021 WebPointLtd. All rights reserved. Created by <a href="http://webpointbd.com" target="_blunk">Web Point Ltd.</a></p>
    </div>
</div>
<!-- END footer-bottom-->
